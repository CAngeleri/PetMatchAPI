﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MomosMatch.Migrations
{
    public partial class Postcomments : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
